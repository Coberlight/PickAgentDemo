﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Form1._5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool IsCtrlPressed = false;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Directories.FillTest();

            Directories.IgnoreFileTypesList.Add(".nfo");
            Directories.IgnoreFileTypesList.Add(".png");
            
            Directories.LeftTabCurrent = 0;
            Directories.FolderNumber = 0;
            Directories.PageQuantity = 16; // default 16
            Directories.PageTemp = 0;
            Directories.ChangeFirst();
            UpdatePage();
        }
        private void Grid1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
                System.Environment.Exit(0);
            } else if (e.Key == Key.LeftCtrl)
            {
                IsCtrlPressed = true;
            } else if (e.Key == Key.B)
            {
                Directories.PressedPolygon = 0;
                SwitchDirectory();
            }
        }
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.LeftCtrl)
            {
                IsCtrlPressed = false;
            }
        }

        
        private void UpdatePage()
        {
            int PageCountTemp = Directories.PageCount;
            if (Directories.DirectoriesListDisplay.Count % Directories.PageQuantity == 0) PageCountTemp -= 1;

            ImageToBeginning.Source = null;
            ImageToEnd.Source = null;

            // кнопки снизу
            if (PageCountTemp == 1)
            {
                //PageSwitches.Margin = new Thickness { Left = 0, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Hidden;
                PageSwitchButton2.Visibility = Visibility.Hidden;
                PageSwitchButton3.Visibility = Visibility.Hidden;
                PageSwitchButton4.Visibility = Visibility.Hidden;
                PageSwitchButton5.Visibility = Visibility.Hidden;
                PageSwitchButton6.Visibility = Visibility.Hidden;
                PageSwitchButton7.Visibility = Visibility.Hidden;
                //PageSwitchButton4.Content = "1";
                //PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
            }
            else if (PageCountTemp == 2)
            {
                PageSwitches.Margin = new Thickness { Left = 65, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Hidden;
                PageSwitchButton2.Visibility = Visibility.Hidden;
                PageSwitchButton3.Visibility = Visibility.Visible;
                PageSwitchButton4.Visibility = Visibility.Visible;
                PageSwitchButton5.Visibility = Visibility.Hidden;
                PageSwitchButton6.Visibility = Visibility.Hidden;
                PageSwitchButton7.Visibility = Visibility.Hidden;
                PageSwitchButton3.Content = "1";
                PageSwitchButton4.Content = "2";
                if (Directories.PageTemp == 0)
                {
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    // АБОБААБОБОААБАОАОАОБАААОБОА
                }
                else
                {
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                }
            }
            else if (PageCountTemp == 3)
            {
                PageSwitches.Margin = new Thickness { Left = 0, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Hidden;
                PageSwitchButton2.Visibility = Visibility.Hidden;
                PageSwitchButton3.Visibility = Visibility.Visible;
                PageSwitchButton4.Visibility = Visibility.Visible;
                PageSwitchButton5.Visibility = Visibility.Visible;
                PageSwitchButton6.Visibility = Visibility.Hidden;
                PageSwitchButton7.Visibility = Visibility.Hidden;
                PageSwitchButton3.Content = "1";
                PageSwitchButton4.Content = "2";
                PageSwitchButton5.Content = "3";
                if (Directories.PageTemp == 0)
                {
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    // АБОБААБОБОААБАОАОАОБАААОБОА
                }
                else if (Directories.PageTemp == 1)
                {
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else
                {
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                }
            }
            else if (PageCountTemp == 4)
            {
                PageSwitches.Margin = new Thickness { Left = 65, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Hidden;
                PageSwitchButton2.Visibility = Visibility.Visible;
                PageSwitchButton3.Visibility = Visibility.Visible;
                PageSwitchButton4.Visibility = Visibility.Visible;
                PageSwitchButton5.Visibility = Visibility.Visible;
                PageSwitchButton6.Visibility = Visibility.Hidden;
                PageSwitchButton7.Visibility = Visibility.Hidden;
                PageSwitchButton2.Content = "1";
                PageSwitchButton3.Content = "2";
                PageSwitchButton4.Content = "3";
                PageSwitchButton5.Content = "4";
                if (Directories.PageTemp == 0)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 1)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    // АБОБААБОБОААБАОАОАОБАААОБОА
                }
                else if (Directories.PageTemp == 2)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                }
            }
            else if (PageCountTemp == 5)
            {
                PageSwitches.Margin = new Thickness { Left = 0, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Hidden;
                PageSwitchButton2.Visibility = Visibility.Visible;
                PageSwitchButton3.Visibility = Visibility.Visible;
                PageSwitchButton4.Visibility = Visibility.Visible;
                PageSwitchButton5.Visibility = Visibility.Visible;
                PageSwitchButton6.Visibility = Visibility.Visible;
                PageSwitchButton7.Visibility = Visibility.Hidden;
                PageSwitchButton2.Content = "1";
                PageSwitchButton3.Content = "2";
                PageSwitchButton4.Content = "3";
                PageSwitchButton5.Content = "4";
                PageSwitchButton6.Content = "5";
                if (Directories.PageTemp == 0)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    // АБОБААБОБОААБАОАОАОБАААОБОА
                }
                else if (Directories.PageTemp == 1)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 2)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 3)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 4)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                }
            }
            else if (PageCountTemp == 6)
            {
                PageSwitches.Margin = new Thickness { Left = 65, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Visible;
                PageSwitchButton2.Visibility = Visibility.Visible;
                PageSwitchButton3.Visibility = Visibility.Visible;
                PageSwitchButton4.Visibility = Visibility.Visible;
                PageSwitchButton5.Visibility = Visibility.Visible;
                PageSwitchButton6.Visibility = Visibility.Visible;
                PageSwitchButton7.Visibility = Visibility.Hidden;
                PageSwitchButton1.Content = "1";
                PageSwitchButton2.Content = "2";
                PageSwitchButton3.Content = "3";
                PageSwitchButton4.Content = "4";
                PageSwitchButton5.Content = "5";
                PageSwitchButton6.Content = "6";
                if (Directories.PageTemp == 0)
                {
                    PageSwitchButton1.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    // АБОБААБОБОААБАОАОАОБАААОБОА
                }
                else if (Directories.PageTemp == 1)
                {
                    PageSwitchButton1.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 2)
                {
                    PageSwitchButton1.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 3)
                {
                    PageSwitchButton1.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 4)
                {
                    PageSwitchButton1.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                }
                else if (Directories.PageTemp == 5)
                {
                    PageSwitchButton1.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                }
            }
            else
            {
                PageSwitches.Margin = new Thickness { Left = 0, Top = 900, Bottom = 0, Right = 0 };
                PageSwitchButton1.Visibility = Visibility.Visible;
                PageSwitchButton2.Visibility = Visibility.Visible;
                PageSwitchButton3.Visibility = Visibility.Visible;
                PageSwitchButton4.Visibility = Visibility.Visible;
                PageSwitchButton5.Visibility = Visibility.Visible;
                PageSwitchButton6.Visibility = Visibility.Visible;
                PageSwitchButton7.Visibility = Visibility.Visible;
                ImageToBeginning.Source = (ImageSource)LeftButton1.FindResource("ArrowToBeginning");
                ImageToEnd.Source = (ImageSource)LeftButton1.FindResource("ArrowToBeginning");
                
                if (Directories.PageTemp == 0)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Content = "1";
                    PageSwitchButton3.Content = "2";
                    PageSwitchButton4.Content = "3";
                    PageSwitchButton5.Content = "4";
                    PageSwitchButton6.Content = "5";
                } 
                else if (Directories.PageTemp == 1)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Content = "1";
                    PageSwitchButton3.Content = "2";
                    PageSwitchButton4.Content = "3";
                    PageSwitchButton5.Content = "4";
                    PageSwitchButton6.Content = "5";
                } 
                else if (Directories.PageTemp == Directories.PageCount - 2)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Content = Convert.ToString(Directories.PageCount - 4);
                    PageSwitchButton3.Content = Convert.ToString(Directories.PageCount - 3);
                    PageSwitchButton4.Content = Convert.ToString(Directories.PageCount - 2);
                    PageSwitchButton5.Content = Convert.ToString(Directories.PageCount - 1);
                    PageSwitchButton6.Content = Convert.ToString(Directories.PageCount);
                } 
                else if (Directories.PageTemp == Directories.PageCount - 1)
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton2.Content = Convert.ToString(Directories.PageCount - 4);
                    PageSwitchButton3.Content = Convert.ToString(Directories.PageCount - 3);
                    PageSwitchButton4.Content = Convert.ToString(Directories.PageCount - 2);
                    PageSwitchButton5.Content = Convert.ToString(Directories.PageCount - 1);
                    PageSwitchButton6.Content = Convert.ToString(Directories.PageCount);
                } 
                else
                {
                    PageSwitchButton2.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton3.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton4.Style = (Style)LeftButton1.FindResource("LeftButtonTabSelected");
                    PageSwitchButton5.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton6.Style = (Style)LeftButton1.FindResource("LeftButtonTab");
                    PageSwitchButton2.Content = Convert.ToString(Directories.PageTemp + 1 - 2);
                    PageSwitchButton3.Content = Convert.ToString(Directories.PageTemp + 1 - 1);
                    PageSwitchButton4.Content = Convert.ToString(Directories.PageTemp + 1);
                    PageSwitchButton5.Content = Convert.ToString(Directories.PageTemp + 1 + 1);
                    PageSwitchButton6.Content = Convert.ToString(Directories.PageTemp + 1 + 2);
                }
            }
            Page1 Page1Instance = new Page1();
            Page1Instance.DirectorySwitched += SwitchDirectory; // 
            Page1Instance.DragDropBegin += HideWindow;
            MainFrame.Content = Page1Instance;
            FindLabel.Text = Convert.ToString(Directories.PageTemp);
            
        }

        private void HideWindow()
        {
            //FindLabel.Text = Directories.CurrentDirectory + @"\" + Directories.DirectoriesListDisplay[Directories.PressedPolygon - 1].FileAndTypeNext.FileFullName;
            this.Hide();
        }

        private void SwitchDirectory()
        {
            if (Directories.IsFolderEmpty())
            {
                FindLabel.Text = "The folder is empty!";
            } else
            {
                Directories.PageTemp = 0;
                //FindLabel.Text = "Catched";
                if (Directories.PressedPolygon == 0) Directories.Back();
                else Directories.Change();
                UpdatePage();
            }
            
        }

        private void SwitchPage(int PageNumber)
        {
            Directories.PageTemp = PageNumber;
            UpdatePage();
        }

        private void SwitchPageButtonPressed(int ButtonID)
        {
            int PageCountTemp = Directories.PageCount;
            if (Directories.DirectoriesListDisplay.Count % Directories.PageQuantity == 0) PageCountTemp -= 1;
            if (PageCountTemp == 1)
            {

            }
            else if(PageCountTemp == 2)
            {
                if (ButtonID == 4 && PageCountTemp != 2 - 1) SwitchPage(2 - 1);
                else if (ButtonID == 3 && PageCountTemp != 1 - 1) SwitchPage(1 - 1);
            } 
            else if (PageCountTemp == 3)
            {
                if (ButtonID == 3 && PageCountTemp != 1 - 1) SwitchPage(1 - 1);
                else if (ButtonID == 4 && PageCountTemp != 2 - 1) SwitchPage(2 - 1);
                else if (ButtonID == 5 && PageCountTemp != 3 - 1) SwitchPage(3 - 1);
            } 
            else if (PageCountTemp == 4)
            {
                if (ButtonID == 2 && PageCountTemp != 1 - 1) SwitchPage(1 - 1);
                else if (ButtonID == 3 && PageCountTemp != 2 - 1) SwitchPage(2 - 1);
                else if (ButtonID == 4 && PageCountTemp != 3 - 1) SwitchPage(3 - 1);
                else if (ButtonID == 5 && PageCountTemp != 4 - 1) SwitchPage(4 - 1);
            } 
            else if (PageCountTemp == 5)
            {
                if (ButtonID == 2 && PageCountTemp != 1 - 1) SwitchPage(1 - 1);
                else if (ButtonID == 3 && PageCountTemp != 2 - 1) SwitchPage(2 - 1);
                else if (ButtonID == 4 && PageCountTemp != 3 - 1) SwitchPage(3 - 1);
                else if (ButtonID == 5 && PageCountTemp != 4 - 1) SwitchPage(4 - 1);
                else if (ButtonID == 6 && PageCountTemp != 5 - 1) SwitchPage(5 - 1);
            } 
            else if (PageCountTemp == 6)
            {
                if (ButtonID == 1 && PageCountTemp != 1 - 1) SwitchPage(1 - 1);
                else if (ButtonID == 2 && PageCountTemp != 2 - 1) SwitchPage(2 - 1);
                else if (ButtonID == 3 && PageCountTemp != 3 - 1) SwitchPage(3 - 1);
                else if (ButtonID == 4 && PageCountTemp != 4 - 1) SwitchPage(4 - 1);
                else if (ButtonID == 5 && PageCountTemp != 5 - 1) SwitchPage(5 - 1);
                else if (ButtonID == 6 && PageCountTemp != 6 - 1) SwitchPage(6 - 1);
            } 
            else
            {
                if (ButtonID == 1)
                {
                    if (Directories.PageTemp != 0) SwitchPage(0);
                    ////FindLabel.Text = "PREV PAGE";
                    //int PrevPage = Directories.PageTemp - 1;
                    //if (PrevPage >= 0)
                    //{
                    //    SwitchPage(PrevPage);
                    //}
                }
                else if (ButtonID == 7)
                {
                    if (Directories.PageTemp != PageCountTemp - 1) SwitchPage(PageCountTemp - 1);
                    ////FindLabel.Text = "NEXT PAGE";
                    //int NextPage = Directories.PageTemp + 1;
                    //if (NextPage <= Directories.PageCount - 1)
                    //{
                    //    if (!(Directories.DirectoriesListDisplay.Count % Directories.PageQuantity == 0 && NextPage == Directories.PageCount - 1))
                    //    {
                    //        SwitchPage(NextPage);
                    //    }
                    //}
                } else
                {
                    if (Directories.PageTemp == 0 || Directories.PageTemp == 1)
                    {
                        SwitchPage(ButtonID - 1 - 1);
                    } 
                    else if (Directories.PageTemp == Directories.PageCount - 2 || Directories.PageTemp == Directories.PageCount - 1)
                    {
                        SwitchPage(Directories.PageCount - 1 + ButtonID - 6);
                    }
                    else
                    {
                        SwitchPage(Directories.PageTemp + ButtonID - 4);
                    }
                }
            }
        }

        private void LeftPageSwitch_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            
        }

        private void Window_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            
            Point MousePos = new Point() { X = e.GetPosition((IInputElement)sender).X - 6, Y = e.GetPosition((IInputElement)sender).Y - 6};
            double pipX = SystemParameters.PrimaryScreenWidth / 1920;
            double pipY = SystemParameters.PrimaryScreenHeight / 1080;
            double sens = 400;
            
            if (MousePos.X > SystemParameters.PrimaryScreenWidth / 2 - sens * pipX &&
                MousePos.X < SystemParameters.PrimaryScreenWidth / 2 + sens * pipX &&
                MousePos.Y > SystemParameters.PrimaryScreenHeight / 2 - sens * pipY &&
                MousePos.Y < SystemParameters.PrimaryScreenHeight / 2 + sens * pipY)
            {
                if (MousePos.X - SystemParameters.PrimaryScreenWidth / 2 < 0)
                {
                    //FindLabel.Text = "PREV PAGE";
                    int PrevPage = Directories.PageTemp - 1;
                    if (PrevPage >= 0)
                    {
                        SwitchPage(PrevPage);
                    }
                }
                else
                {
                    //FindLabel.Text = "NEXT PAGE";
                    int NextPage = Directories.PageTemp + 1;
                    if (NextPage <= Directories.PageCount - 1)
                    {
                        if (!(Directories.DirectoriesListDisplay.Count % Directories.PageQuantity == 0 && NextPage == Directories.PageCount - 1))
                        {
                            SwitchPage(NextPage);
                        }

                    }
                }
            } //else FindLabel.Text = "aboba";
            
            //FindLabel.Text = "LEFT TRIGGER ACTIVATED";
            //FindLabel.Text = Convert.ToString(SystemParameters.PrimaryScreenWidth);

            //FindLabel.Text = Convert.ToString(e.GetPosition((IInputElement)sender).X);
        }

        private void PageSwitchButton1_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(1);
        }

        private void PageSwitchButton2_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(2);
        }

        private void PageSwitchButton3_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(3);
        }

        private void PageSwitchButton4_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(4);
        }

        private void PageSwitchButton5_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(5);
        }

        private void PageSwitchButton6_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(6);
        }

        private void PageSwitchButton7_Click(object sender, RoutedEventArgs e)
        {
            SwitchPageButtonPressed(7);
        }
    }
}
