﻿
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Form1._5
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        //Количество полигонов
        private static int Quantity = 16;
        private static int MaxQuantity = 24;

        // Массив со строками
        private string[] StringArray = new string[MaxQuantity];  // 24 ЭТО ВРЕМЕННОЕ ЗНАЧЕНИЕ!!! (так как цвета мы временно задаём в этом скрипте)

        // Массив с цветами
        private Color[] ColorArray = new Color[MaxQuantity];

        private int PageMode = 0;

        public delegate void MethodContainer();

        public event MethodContainer DirectorySwitched;
        public event MethodContainer DragDropBegin;

        public Page1()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Directories.FolderNumber == 0) PageMode = 1;

            if ((Directories.PageTemp + 1) < Directories.PageCount) Quantity = Directories.PageQuantity;
            else Quantity = Directories.DirectoriesListDisplay.Count % Directories.PageQuantity;

            for (int i = Directories.PageTemp * Directories.PageQuantity; 
                i < (Directories.PageTemp + 1) * Directories.PageQuantity && 
                i < Directories.DirectoriesListDisplay.Count; 
                i++)
            {
                StringArray[i - Directories.PageTemp * Directories.PageQuantity] = Directories.DirectoriesListDisplay[i].PathNext;
                ColorArray[i - Directories.PageTemp * Directories.PageQuantity] = Directories.DirectoriesListDisplay[i].DisplayColor;
            }

            // StringArray[1] = "ABOBAaboba";
            // Создание объекта класса PolygonBuilder

            PolygonBuilder TPolygonBuilder = new PolygonBuilder(Quantity, PageMode);
            
            // Тестовые заполнения массивов
            //StringArray[0] = "Autogun";
            //StringArray[1] = "FLEX";
            //StringArray[2] = "Genesis Pro";
            //StringArray[3] = "Harmless";
            //StringArray[4] = "Harmor";
            //StringArray[5] = "Ogun";
            //StringArray[6] = "Sytrus";
            //StringArray[7] = "Vital";
            //StringArray[8] = "Addictive Keys";
            //StringArray[9] = "Addictive Keys";
            //for (int q = 10; q < Quantity; q++)
            //{
            //    StringArray[q] = "Fruity Parametric EQ 2" + Convert.ToString(q + 1);
            //}
            {
                //ColorArray[0] = Color.FromArgb(0xFF, 0x76, 0xA8, 0x7E); // дефолтный зелёный
                //ColorArray[1] = Color.FromArgb(0xFF, 0x98, 0x70, 0x8F);
                //ColorArray[2] = Color.FromArgb(0xFF, 0x76, 0xA8, 0x7E);
                //ColorArray[3] = Color.FromArgb(0xFF, 0x98, 0x70, 0x8F); // красный аля channel presets
                //ColorArray[4] = Color.FromArgb(0xFF, 0x98, 0x70, 0x8F);
                //ColorArray[5] = Color.FromArgb(0xFF, 0x6B, 0x81, 0x8D); // синий clipboard files 
                //ColorArray[6] = Color.FromArgb(0xFF, 0xAA, 0x80, 0x70); // Current project
                //ColorArray[7] = Color.FromArgb(0xFF, 0xAA, 0x80, 0x70);
                //for (int i = 8; i < Quantity; i++)
                //{
                //    ColorArray[i] = Color.FromArgb(0x00, 0xFF, 0xFF, 0xFF);  // файлы
                //}

            }

            // Заполнение полигонов точками
            {
                // Само заполнение
                int a;
                for (int q = 1; q < Quantity + 1; q++)
                {
                    a = q - 1;
                    if (q == 1)
                    {
                        Polygon1.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 2)
                    {
                        Polygon2.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 3)
                    {
                        Polygon3.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 4)
                    {
                        Polygon4.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 5)
                    {
                        Polygon5.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 6)
                    {
                        Polygon6.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 7)
                    {
                        Polygon7.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 8)
                    {
                        Polygon8.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 9)
                    {
                        Polygon9.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 10)
                    {
                        Polygon10.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 11)
                    {
                        Polygon11.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 12)
                    {
                        Polygon12.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 13)
                    {
                        Polygon13.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 14)
                    {
                        Polygon14.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 15)
                    {
                        Polygon15.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 16)
                    {
                        Polygon16.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 17)
                    {
                        Polygon17.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 18)
                    {
                        Polygon18.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 19)
                    {
                        Polygon19.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 20)
                    {
                        Polygon20.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 21)
                    {
                        Polygon21.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 22)
                    {
                        Polygon22.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 23)
                    {
                        Polygon23.Points = TPolygonBuilder.PointCollectionArray[a];
                    }

                    else if (q == 24)
                    {
                        Polygon24.Points = TPolygonBuilder.PointCollectionArray[a];
                    }
                    Label1.Content = TPolygonBuilder.PointCollectionArray[a].Count;
                }

                // Рамки (внешний вид)
                Polygon[] PolygonBoundsArray = new Polygon[Quantity];
                for (int q = 0; q < Quantity; q++)
                {
                    PolygonBoundsArray[q] = new Polygon();
                    if (Quantity != 1)
                    {
                        PolygonBoundsArray[q].Style = (Style)Polygon1.FindResource("PolygonSimpleBound");
                        PolygonBoundsArray[q].Points = TPolygonBuilder.PointCollectionArray[q];
                        CanvasWithPolygons.Children.Add(PolygonBoundsArray[q]);
                    }

                        
                }
                // Кольцо (внешний вид)
                Polygon RoundBound = new Polygon();
                RoundBound.Points = TPolygonBuilder.PointCollectionForCircleBound;
                RoundBound.Style = (Style)Polygon1.FindResource("PolygonRoundBound");
                CanvasWithPolygons.Children.Add(RoundBound);
            }


            //DockPanelForLabelInMiddle.Margin

            // Создание надписей

            int Shift = 500;
            int LengthX = 145;
            int LengthXTemp;
            int LengthY = 30;

            // Кнопка "Back"
            PolygonCircle.Points = TPolygonBuilder.PointCollectionForCircleMiddleButton;
            if (PageMode == 0)
            {
                DockPanelForLabelInMiddle.Visibility = Visibility.Visible;
                PolygonCircle.Style = (Style)Polygon1.FindResource("PolygonFolderDefault");
                Thickness MarginTemp = new TextBlock().Margin;
                MarginTemp.Left = Shift - TextOnBackButton.Width / 2;
                MarginTemp.Top = Shift - 30;
                DockPanelForLabelInMiddle.Margin = MarginTemp;
            }
            else if (PageMode == 1)
            {
                DockPanelForLabelInMiddle.Visibility = Visibility.Hidden;
                PolygonCircle.Style = (Style)Polygon1.FindResource("PolygonMiddle");
            }


            for (int q = 0; q < Quantity; q++)
            {
                // Создание временного TextBlock
                TextBlock TextBlockTemp = new TextBlock();
                TextBlockTemp.Style = (Style)Polygon1.FindResource("TextOnPolygons");
                TextBlockTemp.Text = StringArray[q]; // ЗАПОЛНЕНИЕ ТЕКСТОМ
                TextBlockTemp.FontSize = 30;
                TextBlockTemp.MaxHeight = LengthY * 6;

                // Ширина
                if (Quantity < 6)
                {
                    LengthXTemp = LengthX;
                }
                else if (Quantity >= 6 && Quantity < 8)
                {
                    LengthXTemp = LengthX - Convert.ToInt32(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263 * 30);
                }
                else if (Quantity >= 8 && Quantity < 10)
                {
                    LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 60);
                    if (Quantity == 9)
                    {
                        if (q == 1 || q == 2 || q == 3 || q == 5 || q == 6 || q == 7) TextBlockTemp.MaxHeight = LengthY * 4;
                    }
                }
                else if (Quantity >= 10 && Quantity < 16)
                {
                    TextBlockTemp.LineHeight = 22;
                    TextBlockTemp.FontSize = 25;
                    if (Quantity == 10) { LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 75); TextBlockTemp.MaxHeight = LengthY * 5; }
                    else if (Quantity == 11) { LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 80); TextBlockTemp.MaxHeight = LengthY * 4; }
                    else if (Quantity == 12) { LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 80); TextBlockTemp.MaxHeight = LengthY * 3; if (q == 11 || q == 5 || q == 0 || q == 4 || q == 6 || q == 10) TextBlockTemp.MaxHeight = LengthY * 4; }
                    else if (Quantity == 13) { LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 80); TextBlockTemp.MaxHeight = LengthY * 3; TextBlockTemp.FontSize = 22; TextBlockTemp.LineHeight = 18; }
                    else if (Quantity == 14) { LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 80); TextBlockTemp.MaxHeight = LengthY * 2.5; TextBlockTemp.FontSize = 22; TextBlockTemp.LineHeight = 18; }
                    else if (Quantity == 15) { LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 80); TextBlockTemp.MaxHeight = LengthY * 2.5; TextBlockTemp.FontSize = 22; TextBlockTemp.LineHeight = 18; }
                    else LengthXTemp = 1;
                }
                else if (Quantity >= 16 && Quantity < 20)
                {

                    LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 80) - (Quantity - 16) * 10;
                    if (Quantity == 18 || Quantity == 19) LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.1) * 65) - (Quantity - 16) * 10;
                    TextBlockTemp.MaxHeight = LengthY * 2.5;
                    TextBlockTemp.FontSize = 22;
                    TextBlockTemp.LineHeight = 20;
                }
                else
                {
                    LengthXTemp = LengthX - Convert.ToInt32(Math.Pow(Math.Abs(TPolygonBuilder.LabelCoordinatesArray[q].Y) / 263, 0.3) * 80) - 10;
                    TextBlockTemp.MaxHeight = LengthY * 2.5;
                    TextBlockTemp.FontSize = 22;
                    TextBlockTemp.LineHeight = 20;
                }

                TextOnBackButton.FontSize = TextBlockTemp.FontSize;

                TextBlockTemp.Width = LengthXTemp * 2;

                // Создание временного TextBlock -> Margin
                Thickness MarginTemp = new TextBlock().Margin;

                TextBlockTemp.Margin = MarginTemp;
                TextBlockTemp.Visibility = Visibility.Visible;

                // Создание временного DockPanel (для выравнивания по вертикали)
                DockPanel DockPanelTemp = new DockPanel();
                DockPanelTemp.Width = LengthX * 4;
                DockPanelTemp.Height = LengthY * 10;

                DockPanelTemp.VerticalAlignment = VerticalAlignment.Center;
                DockPanelTemp.HorizontalAlignment = HorizontalAlignment.Center;
                Thickness MarginTemp2 = new TextBlock().Margin;
                MarginTemp2.Left = TPolygonBuilder.LabelCoordinatesArray[q].X + Shift - LengthX * 2;
                MarginTemp2.Top = TPolygonBuilder.LabelCoordinatesArray[q].Y + Shift - LengthY * 5;

                DockPanelTemp.Margin = MarginTemp2;
                DockPanelTemp.Visibility = Visibility.Visible;
                DockPanelTemp.Children.Add(TextBlockTemp);
                CanvasWithLabels.Children.Add(DockPanelTemp);

                {
                    if (q == 0) { TextBlock1 = DockPanelTemp; TextBlock_1 = TextBlockTemp; }
                    else if (q == 1) { TextBlock2 = DockPanelTemp; TextBlock_2 = TextBlockTemp; }
                    else if (q == 2) { TextBlock3 = DockPanelTemp; TextBlock_3 = TextBlockTemp; }
                    else if (q == 3) { TextBlock4 = DockPanelTemp; TextBlock_4 = TextBlockTemp; }
                    else if (q == 4) { TextBlock5 = DockPanelTemp; TextBlock_5 = TextBlockTemp; }
                    else if (q == 5) { TextBlock6 = DockPanelTemp; TextBlock_6 = TextBlockTemp; }
                    else if (q == 6) { TextBlock7 = DockPanelTemp; TextBlock_7 = TextBlockTemp; }
                    else if (q == 7) { TextBlock8 = DockPanelTemp; TextBlock_8 = TextBlockTemp; }
                    else if (q == 8) { TextBlock9 = DockPanelTemp; TextBlock_9 = TextBlockTemp; }
                    else if (q == 9) { TextBlock10 = DockPanelTemp; TextBlock_10 = TextBlockTemp; }
                    else if (q == 10) { TextBlock11 = DockPanelTemp; TextBlock_11 = TextBlockTemp; }
                    else if (q == 11) { TextBlock12 = DockPanelTemp; TextBlock_12 = TextBlockTemp; }
                    else if (q == 12) { TextBlock13 = DockPanelTemp; TextBlock_13 = TextBlockTemp; }
                    else if (q == 13) { TextBlock14 = DockPanelTemp; TextBlock_14 = TextBlockTemp; }
                    else if (q == 14) { TextBlock15 = DockPanelTemp; TextBlock_15 = TextBlockTemp; }
                    else if (q == 15) { TextBlock16 = DockPanelTemp; TextBlock_16 = TextBlockTemp; }
                    else if (q == 16) { TextBlock17 = DockPanelTemp; TextBlock_17 = TextBlockTemp; }
                    else if (q == 17) { TextBlock18 = DockPanelTemp; TextBlock_18 = TextBlockTemp; }
                    else if (q == 18) { TextBlock19 = DockPanelTemp; TextBlock_19 = TextBlockTemp; }
                    else if (q == 19) { TextBlock20 = DockPanelTemp; TextBlock_20 = TextBlockTemp; }
                    else if (q == 20) { TextBlock21 = DockPanelTemp; TextBlock_21 = TextBlockTemp; }
                    else if (q == 21) { TextBlock22 = DockPanelTemp; TextBlock_22 = TextBlockTemp; }
                    else if (q == 22) { TextBlock23 = DockPanelTemp; TextBlock_23 = TextBlockTemp; }
                    else if (q == 23) { TextBlock24 = DockPanelTemp; TextBlock_24 = TextBlockTemp; }
                }

                TextBlockTemp = null;
                DockPanelTemp = null;

            }

            

            //IDisposable.TPolygonBuilder.Dispose();

            for (int q = 1; q < Quantity + 1; q++)
            {
                PolygonOperation(q, 4);
            }

        }
        private void PolygonOperation(int SelectedPolygon, byte Type)
        {
            // Type == 0 - навели мышь
            // Type == 1 - увели мышь
            // Type == 2 - нажали мышь
            // Type == 3 - отпустили мышь
            // Type == 4 - инициализация полигонов
            // Type == 5 - навелись на Back
            // Type == 6 - увелись с Back

            Polygon PolygonTemp = null;
            TextBlock TextBlockTemp = null;

            // Входные проверки затриггеренного полигона
            {
                if (SelectedPolygon == 1) { PolygonTemp = Polygon1; TextBlockTemp = TextBlock_1; }
                else if (SelectedPolygon == 2) { PolygonTemp = Polygon2; TextBlockTemp = TextBlock_2; }
                else if (SelectedPolygon == 3) { PolygonTemp = Polygon3; TextBlockTemp = TextBlock_3; }
                else if (SelectedPolygon == 4) { PolygonTemp = Polygon4; TextBlockTemp = TextBlock_4; }
                else if (SelectedPolygon == 5) { PolygonTemp = Polygon5; TextBlockTemp = TextBlock_5; }
                else if (SelectedPolygon == 6) { PolygonTemp = Polygon6; TextBlockTemp = TextBlock_6; }
                else if (SelectedPolygon == 7) { PolygonTemp = Polygon7; TextBlockTemp = TextBlock_7; }
                else if (SelectedPolygon == 8) { PolygonTemp = Polygon8; TextBlockTemp = TextBlock_8; }
                else if (SelectedPolygon == 9) { PolygonTemp = Polygon9; TextBlockTemp = TextBlock_9; }
                else if (SelectedPolygon == 10) { PolygonTemp = Polygon10; TextBlockTemp = TextBlock_10; }
                else if (SelectedPolygon == 11) { PolygonTemp = Polygon11; TextBlockTemp = TextBlock_11; }
                else if (SelectedPolygon == 12) { PolygonTemp = Polygon12; TextBlockTemp = TextBlock_12; }
                else if (SelectedPolygon == 13) { PolygonTemp = Polygon13; TextBlockTemp = TextBlock_13; }
                else if (SelectedPolygon == 14) { PolygonTemp = Polygon14; TextBlockTemp = TextBlock_14; }
                else if (SelectedPolygon == 15) { PolygonTemp = Polygon15; TextBlockTemp = TextBlock_15; }
                else if (SelectedPolygon == 16) { PolygonTemp = Polygon16; TextBlockTemp = TextBlock_16; }
                else if (SelectedPolygon == 17) { PolygonTemp = Polygon17; TextBlockTemp = TextBlock_17; }
                else if (SelectedPolygon == 18) { PolygonTemp = Polygon18; TextBlockTemp = TextBlock_18; }
                else if (SelectedPolygon == 19) { PolygonTemp = Polygon19; TextBlockTemp = TextBlock_19; }
                else if (SelectedPolygon == 20) { PolygonTemp = Polygon20; TextBlockTemp = TextBlock_20; }
                else if (SelectedPolygon == 21) { PolygonTemp = Polygon21; TextBlockTemp = TextBlock_21; }
                else if (SelectedPolygon == 22) { PolygonTemp = Polygon22; TextBlockTemp = TextBlock_22; }
                else if (SelectedPolygon == 23) { PolygonTemp = Polygon23; TextBlockTemp = TextBlock_23; }
                else if (SelectedPolygon == 24) { PolygonTemp = Polygon24; TextBlockTemp = TextBlock_24; }
            }

            if (Type == 0) // навели мышь
            {
                // Изменение цвета у надписи
                TextBlockTemp.Style = (Style)Polygon1.FindResource("TextOnPolygonsPointed");

                SolidColorBrush BrushTemp = new SolidColorBrush();
                Color BrigthnessInc = Color.FromArgb(0x00, 0x77, 0x77, 0x77);
                Color Gray = Color.FromArgb(0xFF, 0x95, 0x96, 0x9E);

                // Разделение на файл / папку
                if (Color.Equals(ColorArray[SelectedPolygon - 1], Color.FromArgb(0x00, 0xFF, 0xFF, 0xFF)))
                {
                    PolygonTemp.Style = (Style)Polygon1.FindResource("PolygonFilePointed");
                    BrushTemp.Color = Color.Add(Gray, BrigthnessInc);
                }
                else
                {
                    PolygonTemp.Style = (Style)Polygon1.FindResource("PolygonFolderPointed");
                    BrushTemp.Color = Color.Add(ColorArray[SelectedPolygon - 1], BrigthnessInc);
                }

                TextBlockTemp.Foreground = BrushTemp;

            }
            else if (Type == 1) // увели мышь
            {
                // Изменение цвета у надписи
                TextBlockTemp.Style = (Style)Polygon1.FindResource("TextOnPolygons");

                SolidColorBrush BrushTemp = new SolidColorBrush();
                //Color BrigthnessInc = Color.FromArgb(0x00, 0x77, 0x77, 0x77);
                

                // Разделение на файл / папку
                if (Color.Equals(ColorArray[SelectedPolygon - 1], Color.FromArgb(0x00, 0xFF, 0xFF, 0xFF)))
                {
                    Color Gray = Color.FromArgb(0xFF, 0x95, 0x96, 0x9E);
                    PolygonTemp.Style = (Style)Polygon1.FindResource("PolygonFileDefault");
                    BrushTemp.Color = Gray;
                }
                else
                {
                    PolygonTemp.Style = (Style)Polygon1.FindResource("PolygonFolderDefault");
                    BrushTemp.Color = ColorArray[SelectedPolygon - 1];
                }

                TextBlockTemp.Foreground = BrushTemp;

            }
            else if (Type == 2) // нажали левой кнопкой
            {
                
                Directories.PressedPolygon = SelectedPolygon;
                if (DirectorySwitched != null && (
                    Directories.DirectoriesListDisplay[Directories.PressedPolygon - 1].FileAndTypeNext.FileType == null ||
                    Directories.DirectoriesListDisplay[Directories.PressedPolygon - 1].FileAndTypeNext.FileType == "")) 
                { 
                DirectorySwitched();
                } else
                {
                    DragDropBegin();
                    //DragDrop.DoDragDrop(new Polygon(), new Polygon(), DragDropEffects.Copy);
                    

                    ProcessDrop(Directories.CurrentDirectory + @"\" + Directories.DirectoriesListDisplay[Directories.PressedPolygon - 1].FileAndTypeNext.FileFullName);
                    // Directories.PressedPolygon
                    
                    //System.Environment.Exit(0);
                }
            }
            else if (Type == 3) // отпустили левой кнопкой
            {
                Label1.Content = SelectedPolygon;
            }
            else if (Type == 4) // инициализация полигонов
            {
                SolidColorBrush BrushTemp = new SolidColorBrush();
                if (Color.Equals(ColorArray[SelectedPolygon - 1], Color.FromArgb(0x00, 0xFF, 0xFF, 0xFF)))
                {
                    Color Gray = Color.FromArgb(0xFF, 0x95, 0x96, 0x9E);
                    PolygonTemp.Style = (Style)Polygon1.FindResource("PolygonFileDefault");
                    BrushTemp.Color = Gray;
                }
                else
                {
                    PolygonTemp.Style = (Style)Polygon1.FindResource("PolygonFolderDefault");
                    BrushTemp.Color = ColorArray[SelectedPolygon - 1];
                }

                // Обновление надписей (стили)
                TextBlockTemp.Style = (Style)Polygon1.FindResource("TextOnPolygons");

                //Color BrigthnessInc = Color.FromArgb(0x00, 0x77, 0x77, 0x77);

                TextBlockTemp.Foreground = BrushTemp;
            }
            
                //Выходные проверки затриггеренного полигона
                {
                    if (SelectedPolygon == 1) { Polygon1 = PolygonTemp; TextBlock_1 = TextBlockTemp; }
                    else if (SelectedPolygon == 2) { Polygon2 = PolygonTemp; TextBlock_2 = TextBlockTemp; }
                    else if (SelectedPolygon == 3) { Polygon3 = PolygonTemp; TextBlock_3 = TextBlockTemp; }
                    else if (SelectedPolygon == 4) { Polygon4 = PolygonTemp; TextBlock_4 = TextBlockTemp; }
                    else if (SelectedPolygon == 5) { Polygon5 = PolygonTemp; TextBlock_5 = TextBlockTemp; }
                    else if (SelectedPolygon == 6) { Polygon6 = PolygonTemp; TextBlock_6 = TextBlockTemp; }
                    else if (SelectedPolygon == 7) { Polygon7 = PolygonTemp; TextBlock_7 = TextBlockTemp; }
                    else if (SelectedPolygon == 8) { Polygon8 = PolygonTemp; TextBlock_8 = TextBlockTemp; }
                    else if (SelectedPolygon == 9) { Polygon9 = PolygonTemp; TextBlock_9 = TextBlockTemp; }
                    else if (SelectedPolygon == 10) { Polygon10 = PolygonTemp; TextBlock_10 = TextBlockTemp; }
                    else if (SelectedPolygon == 11) { Polygon11 = PolygonTemp; TextBlock_11 = TextBlockTemp; }
                    else if (SelectedPolygon == 12) { Polygon12 = PolygonTemp; TextBlock_12 = TextBlockTemp; }
                    else if (SelectedPolygon == 13) { Polygon13 = PolygonTemp; TextBlock_13 = TextBlockTemp; }
                    else if (SelectedPolygon == 14) { Polygon14 = PolygonTemp; TextBlock_14 = TextBlockTemp; }
                    else if (SelectedPolygon == 15) { Polygon15 = PolygonTemp; TextBlock_15 = TextBlockTemp; }
                    else if (SelectedPolygon == 16) { Polygon16 = PolygonTemp; TextBlock_16 = TextBlockTemp; }
                    else if (SelectedPolygon == 17) { Polygon17 = PolygonTemp; TextBlock_17 = TextBlockTemp; }
                    else if (SelectedPolygon == 18) { Polygon18 = PolygonTemp; TextBlock_18 = TextBlockTemp; }
                    else if (SelectedPolygon == 19) { Polygon19 = PolygonTemp; TextBlock_19 = TextBlockTemp; }
                    else if (SelectedPolygon == 20) { Polygon20 = PolygonTemp; TextBlock_20 = TextBlockTemp; }
                    else if (SelectedPolygon == 21) { Polygon21 = PolygonTemp; TextBlock_21 = TextBlockTemp; }
                    else if (SelectedPolygon == 22) { Polygon22 = PolygonTemp; TextBlock_22 = TextBlockTemp; }
                    else if (SelectedPolygon == 23) { Polygon23 = PolygonTemp; TextBlock_23 = TextBlockTemp; }
                    else if (SelectedPolygon == 24) { Polygon24 = PolygonTemp; TextBlock_24 = TextBlockTemp; }

                }
            
        }
        //CodeGen Spam


        private void Polygon1_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(1, 0);
        }

        private void Polygon1_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(1, 1);
        }

        private void Polygon1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(1, 2);
        }

        private void Polygon1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(1, 3);
        }

        private void Polygon2_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(2, 0);
        }

        private void Polygon2_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(2, 1);
        }

        private void Polygon2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(2, 2);
        }

        private void Polygon2_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(2, 3);
        }

        private void Polygon3_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(3, 0);
        }

        private void Polygon3_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(3, 1);
        }

        private void Polygon3_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(3, 2);
        }

        private void Polygon3_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(3, 3);
        }

        private void Polygon4_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(4, 0);
        }

        private void Polygon4_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(4, 1);
        }

        private void Polygon4_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(4, 2);
        }

        private void Polygon4_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(4, 3);
        }

        private void Polygon5_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(5, 0);
        }

        private void Polygon5_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(5, 1);
        }

        private void Polygon5_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(5, 2);
        }

        private void Polygon5_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(5, 3);
        }

        private void Polygon6_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(6, 0);
        }

        private void Polygon6_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(6, 1);
        }

        private void Polygon6_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(6, 2);
        }

        private void Polygon6_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(6, 3);
        }

        private void Polygon7_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(7, 0);
        }

        private void Polygon7_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(7, 1);
        }

        private void Polygon7_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(7, 2);
        }

        private void Polygon7_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(7, 3);
        }

        private void Polygon8_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(8, 0);
        }

        private void Polygon8_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(8, 1);
        }

        private void Polygon8_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(8, 2);
        }

        private void Polygon8_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(8, 3);
        }

        private void Polygon9_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(9, 0);
        }

        private void Polygon9_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(9, 1);
        }

        private void Polygon9_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(9, 2);
        }

        private void Polygon9_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(9, 3);
        }

        private void Polygon10_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(10, 0);
        }

        private void Polygon10_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(10, 1);
        }

        private void Polygon10_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(10, 2);
        }

        private void Polygon10_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(10, 3);
        }

        private void Polygon11_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(11, 0);
        }

        private void Polygon11_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(11, 1);
        }

        private void Polygon11_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(11, 2);
        }

        private void Polygon11_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(11, 3);
        }

        private void Polygon12_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(12, 0);
        }

        private void Polygon12_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(12, 1);
        }

        private void Polygon12_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(12, 2);
        }

        private void Polygon12_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(12, 3);
        }

        private void Polygon13_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(13, 0);
        }

        private void Polygon13_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(13, 1);
        }

        private void Polygon13_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(13, 2);
        }

        private void Polygon13_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(13, 3);
        }

        private void Polygon14_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(14, 0);
        }

        private void Polygon14_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(14, 1);
        }

        private void Polygon14_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(14, 2);
        }

        private void Polygon14_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(14, 3);
        }

        private void Polygon15_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(15, 0);
        }

        private void Polygon15_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(15, 1);
        }

        private void Polygon15_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(15, 2);
        }

        private void Polygon15_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(15, 3);
        }

        private void Polygon16_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(16, 0);
        }

        private void Polygon16_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(16, 1);
        }

        private void Polygon16_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(16, 2);
        }

        private void Polygon16_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(16, 3);
        }

        private void Polygon17_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(17, 0);
        }

        private void Polygon17_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(17, 1);
        }

        private void Polygon17_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(17, 2);
        }

        private void Polygon17_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(17, 3);
        }

        private void Polygon18_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(18, 0);
        }

        private void Polygon18_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(18, 1);
        }

        private void Polygon18_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(18, 2);
        }

        private void Polygon18_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(18, 3);
        }

        private void Polygon19_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(19, 0);
        }

        private void Polygon19_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(19, 1);
        }

        private void Polygon19_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(19, 2);
        }

        private void Polygon19_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(19, 3);
        }

        private void Polygon20_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(20, 0);
        }

        private void Polygon20_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(20, 1);
        }

        private void Polygon20_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(20, 2);
        }

        private void Polygon20_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(20, 3);
        }

        private void Polygon21_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(21, 0);
        }

        private void Polygon21_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(21, 1);
        }

        private void Polygon21_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(21, 2);
        }

        private void Polygon21_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(21, 3);
        }

        private void Polygon22_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(22, 0);
        }

        private void Polygon22_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(22, 1);
        }

        private void Polygon22_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(22, 2);
        }

        private void Polygon22_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(22, 3);
        }

        private void Polygon23_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(23, 0);
        }

        private void Polygon23_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(23, 1);
        }

        private void Polygon23_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(23, 2);
        }

        private void Polygon23_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(23, 3);
        }

        private void Polygon24_MouseEnter(object sender, MouseEventArgs e)
        {
            PolygonOperation(24, 0);
        }

        private void Polygon24_MouseLeave(object sender, MouseEventArgs e)
        {
            PolygonOperation(24, 1);
        }

        private void Polygon24_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(24, 2);
        }

        private void Polygon24_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PolygonOperation(24, 3);
        }



        private void PolygonCircle_MouseEnter(object sender, MouseEventArgs e)
        {
            if (PageMode == 0)
            {
                PolygonCircle.Style = (Style)Polygon1.FindResource("PolygonFolderPointed");
                SolidColorBrush BrushTemp = new SolidColorBrush();
                Color BrigthnessInc = Color.FromArgb(0x00, 0x77, 0x77, 0x77);
                Color Gray = Color.FromArgb(0xFF, 0x95, 0x96, 0x9E);
                BrushTemp.Color = Color.Add(BrigthnessInc, Gray);

                TextOnBackButton.Foreground = BrushTemp;
                BackImage.Source = (DrawingImage)Polygon1.FindResource("BackArrowDrawingImagePointed");
            }
        }

        private void PolygonCircle_MouseLeave(object sender, MouseEventArgs e)
        {
            if (PageMode == 0)
            {
                PolygonCircle.Style = (Style)Polygon1.FindResource("PolygonFolderDefault");
                SolidColorBrush BrushTemp = new SolidColorBrush();
                Color Gray = Color.FromArgb(0xFF, 0x95, 0x96, 0x9E);
                BrushTemp.Color = Gray;

                TextOnBackButton.Foreground = BrushTemp;
                BackImage.Source = (DrawingImage)Polygon1.FindResource("BackArrowDrawingImage");
            }
        }

        private void ProcessDrop(string FileFullName)//(object sender, MouseButtonEventArgs e)
        {
            //var element = (FrameworkElement)e.OriginalSource;
            FileInfo fileInfo = new FileInfo(FileFullName);//(FileInfo)element.DataContext;
            string[] files = { fileInfo.FullName };
            var data = new DataObject(DataFormats.FileDrop, files);
            data.SetData(DataFormats.Text, files[0]);
            DragDrop.DoDragDrop(this, data, DragDropEffects.Copy);
        }

        private void PolygonCircle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Directories.PressedPolygon = 0;
            DirectorySwitched?.Invoke();
        }
    }


}
