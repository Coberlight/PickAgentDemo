﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;

namespace Form1._5
{
    
    class PolygonBuilder
    {
        private PointCollection[] _pointCollectionArray;
        public PointCollection[] PointCollectionArray
        {
            get { return _pointCollectionArray; }
            set { _pointCollectionArray = value; }
        }

        private Point[] _labelCoordinatesArray;
        public Point[] LabelCoordinatesArray
        {
            get { return _labelCoordinatesArray; }
            set { _labelCoordinatesArray = value; }
        }

        private PointCollection _pointCollectionForCircleBound = new PointCollection();
        public PointCollection PointCollectionForCircleBound
        {
            get { return _pointCollectionForCircleBound; }
            set { _pointCollectionForCircleBound = value; }
        }

        private PointCollection _pointCollectionForCircleMiddleButton = new PointCollection();
        public PointCollection PointCollectionForCircleMiddleButton
        {
            get { return _pointCollectionForCircleMiddleButton; }
            set { _pointCollectionForCircleMiddleButton = value; }
        }

        private double PhaseShift = 3 * Math.PI / 2;
        private double RadiusLower = 80;  // default 100
        public readonly double RadiusHigher = 400;  // default 425
        

        //Type = 0 => с кнопкой "Назад"
        //Type = 1 => без кнопки "Назад"
        public PolygonBuilder(int Quantity, int Type)
        {
            PointCollectionArray = new PointCollection[Quantity];
            LabelCoordinatesArray = new Point[Quantity];
            if (Type == 0)
            {
                FillPointCollection(0);
                FillLabelCoordinatesCollection();
            } else if (Type == 1)
            {
                FillPointCollection(1);
                FillLabelCoordinatesCollection();
            }
        }

        private void FillPointCollection(int Mode)
        {
            if (Mode == 0 || Mode == 1) 
            {
                if (Mode == 1) RadiusLower = 80;
                int Quantity = PointCollectionArray.Length;
                int Phase;
                int StartPhase;
                int EndPhase;
                int MaxPhase = 1000;
                int DetailLower = 20;  // default 20
                int DetailHigher = 8;  // default 7
                double Argument;

                if (Quantity % 4 == 0) PhaseShift = 3 * Math.PI / 2 + Math.PI / Quantity; // фазовый сдвиг если кратно 4

                for (int q = 0; q < Quantity; q++)
                {
                    PointCollectionArray[q] = new PointCollection();
                    // PointCollectionArray[q]
                    StartPhase = Convert.ToInt32((Convert.ToDouble(q) / Convert.ToDouble(Quantity)) * MaxPhase);
                    EndPhase = Convert.ToInt32(((Convert.ToDouble(q) + 1) / Convert.ToDouble(Quantity)) * MaxPhase);

                    Phase = StartPhase;

                    while (Phase < EndPhase) // - DetailHigher
                    {
                        Argument = RealPhase(Phase, MaxPhase) + PhaseShift;
                        PointCollectionArray[q].Add(new Point(RadiusHigher * Math.Cos(Argument), RadiusHigher * Math.Sin(Argument)));
                        Phase += DetailHigher;
                    }
                    Phase = Phase - DetailHigher;

                    Argument = RealPhase(EndPhase, MaxPhase) + PhaseShift;
                    PointCollectionArray[q].Add(new Point(RadiusHigher * Math.Cos(Argument), RadiusHigher * Math.Sin(Argument)));

                    PointCollectionArray[q].Add(new Point(RadiusLower * Math.Cos(Argument), RadiusLower * Math.Sin(Argument)));

                    while (Phase > StartPhase)
                    {
                        Argument = RealPhase(Phase, MaxPhase) + PhaseShift;
                        PointCollectionArray[q].Add(new Point(RadiusLower * Math.Cos(Argument), RadiusLower * Math.Sin(Argument)));
                        Phase -= DetailLower;
                    }
                    Argument = RealPhase(StartPhase, MaxPhase) + PhaseShift;
                    PointCollectionArray[q].Add(new Point(RadiusLower * Math.Cos(Argument), RadiusLower * Math.Sin(Argument)));
                }

                // Кольца
                double RadiusHigherTemp = RadiusHigher + 2;

                PointCollectionForCircleBound = new PointCollection();

                for (Phase = 0; Phase < MaxPhase; Phase += DetailHigher)
                {
                    Argument = RealPhase(Phase, MaxPhase);
                    PointCollectionForCircleBound.Add(new Point(RadiusHigherTemp * Math.Cos(Argument), RadiusHigherTemp * Math.Sin(Argument)));
                }

                for (Phase = 0; Phase < MaxPhase; Phase += DetailLower)
                {
                    Argument = RealPhase(Phase, MaxPhase);
                    PointCollectionForCircleMiddleButton.Add(new Point(RadiusLower * Math.Cos(Argument), RadiusLower * Math.Sin(Argument)));
                }
            }
            else if (Mode == 2)
            {
                
            }
        }


        private void FillLabelCoordinatesCollection()
        {
            int Phase;
            int PhaseShiftLocal;
            int MaxPhase = 1000;
            double Radius = RadiusHigher / 1.6;
            double RadiusInc = 0;
            double Argument;

            if (LabelCoordinatesArray.Length > 5)
            {
                RadiusInc = 0.1 * Math.Sqrt(LabelCoordinatesArray.Length - 5);
            }
            //double VerticalMultiplier = 0.5 + LabelCoordinatesArray.Length * 0.1;

            PhaseShiftLocal = Convert.ToInt32((1 / (2 * Convert.ToDouble(LabelCoordinatesArray.Length))) * MaxPhase);

            for (int i = 0; i < LabelCoordinatesArray.Length; i++)
            {
                Phase = Convert.ToInt32(Convert.ToDouble(i) / Convert.ToDouble(LabelCoordinatesArray.Length) * 1000) + PhaseShiftLocal;
                Argument = RealPhase(Phase, MaxPhase) + PhaseShift;

                if (LabelCoordinatesArray.Length < 8) LabelCoordinatesArray[i] = new Point(RadiusTempCalculate(Radius, RadiusInc, Argument) * Math.Cos(Argument), RadiusTempCalculate(Radius, RadiusInc, Argument) * Math.Sin(Argument));
                else LabelCoordinatesArray[i] = new Point(RadiusTempCalculate(Radius, RadiusInc, Argument) * Math.Cos(Argument) * XInc(Argument), RadiusTempCalculate(Radius, RadiusInc, Argument) * Math.Sin(Argument));
            }
        }

        private double RealPhase(int Phase, int MaxPhase)
        {
            return (Convert.ToDouble(Phase) / Convert.ToDouble(MaxPhase)) * Math.PI * 2;
        }
        private double XInc(double Argument)
        {
            return 1 + (Math.Pow(Math.Abs(Math.Asin(Math.Cos(Argument))) * 2 / Math.PI, 1.5)) * 0.1;
        }

        private double RadiusTempCalculate(double Radius, double RadiusInc, double Argument)
        {
            //Argument += Math.PI;
            double Curve = 2;
            return Radius + RadiusInc * Radius * (1 - Math.Pow(Math.Abs(Math.Asin(Math.Cos(Argument))) * 2 / Math.PI, Curve));
        }
    }
}
