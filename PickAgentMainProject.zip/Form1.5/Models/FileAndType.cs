﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Form1._5
{
    struct FileAndType
    {
        private string _type;
        public string FileType
        {
            get { return _type; }
            
        }
        private string _name;
        public string FileName
        {
            get { return _name; }
        }
        private string _fullname;
        public string FileFullName
        {
            get { return _fullname; }
            set { _fullname = value; }
        }
        public FileAndType(string Input)
        {
            int i = Input.Length;
            while (i > 0 && Input[i - 1] != '.') i--;

            _fullname = Input;
            if (i == 0)
            {
                _name = Input;
                _type = "";
            } else
            {
                _name = Input.Substring(0, i - 1);
                _type = Input.Substring(i - 1, Input.Length - i + 1);
            }
            _type = _type.ToLower();
            
            //_name = Input;
        }
    }
}
