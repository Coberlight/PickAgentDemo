﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Form1._5
{
    class DisplayModel
    {
        private string _path;
        public string PathNext
        {
            get { return _path; }
            set { _path = value; }
        }
        private Color _displayColor;
        public Color DisplayColor
        {
            get { return _displayColor; }
            set { _displayColor = value; }
        }
        private bool _isFile;
        public bool IsFile
        {
            get { return _isFile; }
            set { _isFile = value; }
        }

        private FileAndType _fileAndTypeNext;
        public FileAndType FileAndTypeNext
        {
            get { return _fileAndTypeNext; }
            set { _fileAndTypeNext = value; }
        }

        public DisplayModel()
        {

        }
        public DisplayModel(string PathTemp, Color DisplayColorTemp, bool IsFileTemp)
        {
            _path = PathTemp;
            _displayColor = DisplayColorTemp;
            _isFile = IsFileTemp;
        }

        public DisplayModel(FileAndType FileAndTypeTemp, Color DisplayColorTemp, bool IsFileTemp)
        {
            _fileAndTypeNext = FileAndTypeTemp;
            _path = FileAndTypeTemp.FileName;
            _displayColor = DisplayColorTemp;
            _isFile = IsFileTemp;
        }
    }
}
