﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Diagnostics;
using System.Text;
using System.Windows.Media;

namespace Form1._5
{
    class Directories
    {

        private static BindingList<StoreModel> _directoriesList = new BindingList<StoreModel>();
        public static BindingList<StoreModel> DirectoriesList
        {
            get { return _directoriesList; }
            set { _directoriesList = value; }
        }
        private static BindingList<DisplayModel> _directoriesListDisplay = new BindingList<DisplayModel>();
        public static BindingList<DisplayModel> DirectoriesListDisplay
        {
            get { return _directoriesListDisplay; }
            set { _directoriesListDisplay = value; }
        }
        public static bool IsEnabledFileTypes  //  включено ли отображение типов файлов?
        {
            get { return _isEnabledFileTypes; }
            set { _isEnabledFileTypes = value; }
        }
        private static BindingList<string> _ignoreFileTypesList = new BindingList<string>();
        public static BindingList<string> IgnoreFileTypesList
        {
            get { return _ignoreFileTypesList; }
            set { _ignoreFileTypesList = value; }
        }


        //private static string _currentDirectory;
        //public static string CurrentDirectory
        //{
        //    get { return _currentDirectory; }
        //    set { _currentDirectory = value; }
        //}
        private static int _page;
        public static int PageTemp
        {
            get { return _page; }
            set { _page = value; }
        }
        private static int _pageCount;
        public static int PageCount
        {
            get { return _pageCount; }
            set { _pageCount = value; }
        }
        private static int _pageQuantity;
        public static int PageQuantity
        {
            get { return _pageQuantity; }
            set { _pageQuantity = value; }
        }
        private static int _leftTabCurrent;
        public static int LeftTabCurrent
        {
            get { return _leftTabCurrent; }
            set { _leftTabCurrent = value; }
        }
        private static int _FolderNumber;
        public static int FolderNumber
        {
            get { return _FolderNumber; }
            set { _FolderNumber = value; }
        }
        private static string _currentDirectory;
        public static string CurrentDirectory
        {
            get { return _currentDirectory; }
            set { _currentDirectory = value; }
        }
        private static int _pressedPolygon;
        public static int PressedPolygon { get { return _pressedPolygon; } set { _pressedPolygon = value; } }
        private static bool _isEnabledFileTypes;

        public Directories()
        {
            
            // ВРЕМЕННО
        }

        public static void FillTest() // СЮДА ПИШЕМ ПУТИ ПАПОК, КОТОРЫЕ НУЖНО ОТОБРАЗИТЬ НА НАЧАЛЬНОЙ СТРАНИЦЕ
        {
            DirectoriesList.Add(new StoreModel { NButton = 0, Path = @"E:\MainData\Documents\Image-Line\FL Studio\Presets\Plugin database\Effects" });
            DirectoriesList.Add(new StoreModel { NButton = 0, Path = @"E:\MainData\Documents\Image-Line\FL Studio\Presets\Plugin database\Generators" });
            //DirectoriesList.Add(new StoreModel { NButton = 0, Path = @"E:\MainData" });
        }

        public static void ChangeFirst()
        {
            LookForFirst();
            if (DirectoriesListDisplay.Count % PageQuantity == 0)
                PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
            else PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
        }
        public static void LookForFirst()
        {
            DirectoriesListDisplay.Clear();

            for (int i = 0; i < DirectoriesList.Count; i++)
            {
                if (DirectoriesList[i].NButton == 0)
                {
                    DirectoryInfo DirectoryInfoTemp = new DirectoryInfo(DirectoriesList[i].Path);
                    DirectoriesListDisplay.Add(new DisplayModel { DisplayColor = Color.FromArgb(0xFF, 0xFF, 0xFF, 0x77), PathNext = DirectoriesList[i].Path.Substring(DirectoryInfoTemp.Parent.FullName.Length + 1, DirectoriesList[i].Path.Length - DirectoryInfoTemp.Parent.FullName.Length - 1) });
                }
            }
        }
        //public static void 
        public static void LookFor()
        {
            //PageQuantity = 16;

            FillTest();
            DirectoriesListDisplay.Clear();

            for (int i = 0; i < DirectoriesList.Count; i++)
            {
                DirectoryInfo DirectoryInfoTemp = new DirectoryInfo(DirectoriesList[i].Path);
                int FolderCountTemp = DirectoryInfoTemp.GetDirectories().GetLength(0);
                for (int j = 0; j < FolderCountTemp; j++)
                {
                    DirectoriesListDisplay.Add(new DisplayModel(DirectoryInfoTemp.GetDirectories()[j].Name, Color.FromRgb(0xFF, 0xFF, 0x77), false));
                }
            }

            //for (int i = 0; i < 300; i++) // 13 first max
            //DirectoriesListDisplay.Add(new DisplayModel { DisplayColor = ColorFactor1(i), PathNext = "ABOBUS" });

            if (DirectoriesListDisplay.Count % PageQuantity == 0)
                PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
            else PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
        }
        public static void LookForFoldersAndFiles(DirectoryInfo DirectoryInfoTemp)
        {
            int FolderCountTemp = DirectoryInfoTemp.GetDirectories().GetLength(0);
            DirectoriesListDisplay.Clear();
            for (int j = 0; j < FolderCountTemp; j++)
            {
                DirectoriesListDisplay.Add(new DisplayModel(new FileAndType(DirectoryInfoTemp.GetDirectories()[j].Name), ColorFactor1(j), false));  // Color.FromArgb(0xFF, 0xFF, 0xFF, 0x77)
            }

            int FileCountTemp = DirectoryInfoTemp.GetFiles().Length;
            for (int j = 0; j < FileCountTemp; j++)
            {
                FileAndType FileAndTypeTemp = new FileAndType(DirectoryInfoTemp.GetFiles()[j].Name);
                bool AllowAdd = true;
                for (int k = 0; k < IgnoreFileTypesList.Count; k++)
                    if (FileAndTypeTemp.FileType == IgnoreFileTypesList[k]) AllowAdd = false;
                if (AllowAdd)
                {
                    DirectoriesListDisplay.Add(new DisplayModel(new FileAndType(DirectoryInfoTemp.GetFiles()[j].Name), Color.FromArgb(0x00, 0xFF, 0xFF, 0xFF), true));
                    //DirectoriesListDisplay.Add(new DisplayModel((FileAndTypeTemp.FileType), Color.FromArgb(0x00, 0xFF, 0xFF, 0xFF), true));
                }

            }
            
        }
        public static void Change()
        {
            
            if (FolderNumber == 0)
            {
                CurrentDirectory = DirectoriesList[PressedPolygon - 1].Path;
                DirectoryInfo DirectoryInfoTemp = new DirectoryInfo(CurrentDirectory);
                LookForFoldersAndFiles(DirectoryInfoTemp);

                FolderNumber += 1;
            }
            else
            {
                CurrentDirectory = CurrentDirectory + @"\" + DirectoriesListDisplay[PressedPolygon - 1].PathNext;
                DirectoryInfo DirectoryInfoTemp = new DirectoryInfo(CurrentDirectory);

                LookForFoldersAndFiles(DirectoryInfoTemp);
                FolderNumber += 1;
            }
            if (DirectoriesListDisplay.Count % PageQuantity == 0)
                PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
            else PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;

        }
        public static void Back()
        {
            
        if (FolderNumber != 0)
            {
                FolderNumber -= 1;
                if (FolderNumber == 0)
                {
                    CurrentDirectory = null;
                    ChangeFirst();
                } 
                else
                {
                    DirectoryInfo DirectoryInfoTemp = new DirectoryInfo(CurrentDirectory).Parent;
                    CurrentDirectory = DirectoryInfoTemp.FullName;

                    LookForFoldersAndFiles(DirectoryInfoTemp);
                }
                if (DirectoriesListDisplay.Count % PageQuantity == 0)
                    PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
                else PageCount = DirectoriesListDisplay.Count / PageQuantity + 1;
            }
        }
        public static bool IsFolderEmpty()
        {
            return false;
            //string CurrentDirectoryTemp;
            


            
            

        }


        private static Color ColorFactor1(double Argument)
        {
            byte Maximum = 255;
            double Phase = 0.5 * Math.PI;
            double Divider = 10;
            double Saturation = 0.4; // default 0.25
            
            return Color.FromArgb(
                0xFF,
                Convert.ToByte(Maximum * ((Math.Sin(Argument * Math.PI / Divider + Phase) * 0.5 + 0.5) * Saturation + (0.5 - Saturation / 2))), 
                Convert.ToByte(Maximum * ((Math.Sin(Argument * Math.PI / Divider + 2 * Math.PI / 3 + Phase) * 0.5 + 0.5) * Saturation + (0.5 - Saturation / 2))), 
                Convert.ToByte(Maximum * ((Math.Sin(Argument * Math.PI / Divider + 4 * Math.PI / 3 + Phase) * 0.5 + 0.5) * Saturation + (0.5 - Saturation / 2)))
                );
        }

    }
}
