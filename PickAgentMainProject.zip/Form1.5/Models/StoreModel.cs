﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Form1._5
{
    class StoreModel
    {
        private int _nButton;
        public int NButton
        {
            get { return _nButton; }
            set { _nButton = value; }
        }
        private string _path;
        public string Path
        {
            get { return _path; }
            set { _path = value; }
        }
        private Color _folderColor;
        public Color FolderColor
        {
            get { return _folderColor; }
            set { _folderColor = value; }
        }
    }
}
